
#ifndef Wizard_h
#define Wizard_h

#include "GameCharacter.h"
class Wizard: public GameCharacter{
public:
    Wizard();
};
#endif /* Wizard_h */
