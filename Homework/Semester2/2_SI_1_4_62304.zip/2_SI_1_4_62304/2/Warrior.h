
#ifndef Warrior_h
#define Warrior_h
#include "GameCharacter.h"
class Warrior: public GameCharacter{
public:
    Warrior();
};

#endif /* Warrior_h */
