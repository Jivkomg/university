
#ifndef Guardian_h
#define Guardian_h
#include "GameCharacter.h"
class Guardian: public GameCharacter{
public:
    Guardian();
};

#endif /* Guardian_h */
