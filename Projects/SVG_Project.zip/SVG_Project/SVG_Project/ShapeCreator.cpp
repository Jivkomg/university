////
////  ShapeCreator.cpp
////  SVG_Project
////
////  Created by Zhivko Georgiev on 17.06.19.
////  Copyright © 2019 Zhivko Georgiev. All rights reserved.
////
//
//#include "ShapeCreator.h"
//#include "Line.h"
//#include "Rectangle.h"
//#include "Circle.h"
//BasicShape* ShapeCreator::createShape(const std::string& type) const {
//    if(type == "rectangle"){
//        return new Rectangle();
//    }
//    else if(type == "line"){
//        return new Line();
//    }
//    else if(type == "circle"){
//        return new Circle();
//    }
//    else {
//        return nullptr;
//    }
//    
//}

// TODO remove if unneeded
