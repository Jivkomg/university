//
//  main.cpp
//  SVG_Project
//
//  Created by Zhivko Georgiev on 29.05.19.
//  Copyright © 2019 Zhivko Georgiev. All rights reserved.
//

#include <iostream>
#include <sstream>
//#include "UserInterface.h"
int main() {
    


    return 0;
}
